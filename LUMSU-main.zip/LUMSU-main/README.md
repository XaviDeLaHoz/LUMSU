# Proyecto-LUMSU
{Español}
<br>
(NO DOCUMENTACIÓN)<br>
El proyecto de Incentivo al Reciclaje para el Alquiler de Bicicletas busca motivar a las personas a reciclar botellas plásticas. A través de una plataforma, los usuarios pueden registrar las botellas recicladas, acumulando puntos que luego pueden canjear por el alquiler de bicicletas.<br>
Los usuarios pueden registrarse, actualizar sus datos, cambiar su contraseña y consultar su progreso en la plataforma. Además, hay un Ranking que destaca a los recicladores más activos, fomentando la competencia amigable.Una vez que un usuario acumula suficientes puntos, puede redimirlos en la sección correspondiente para disfrutar del servicio de bicicletas.<br>
El sistema también incluye un área para administradores, encargada de gestionar usuarios y monitorear el reciclaje. De esta manera, el proyecto une la conciencia ambiental con la movilidad sostenible, incentivando el reciclaje a cambio de un beneficio concreto.
<br>
<br>
{English}
<br>
(NO DOCUMENTATION)<br>
The Recycling Incentive for Bike Rental project aims to encourage people to recycle plastic bottles. Through a platform, users can register the bottles they have recycled, accumulating points that they can later redeem for bike rentals.<br> Users can register, update their information, change their password, and track their progress on the platform. There is also a Ranking that highlights the most active recyclers, fostering friendly competition. Once a user has accumulated enough points, they can redeem them in the corresponding section to enjoy the bike rental service.<br> The system also includes an administrator section, responsible for managing users and monitoring recycling activity. In this way, the project combines environmental awareness with sustainable mobility, encouraging recycling in exchange for a tangible benefit.

# Fotos
![image](https://github.com/user-attachments/assets/f7986672-5781-4a97-a838-d5934507f9e3)

# Créditos
{Español}
<br>
Este proyecto fue realizado el semestre 2021-2 de mi carrera universitaria. colaboré en su momento en gran parte de la lógica y el código del programa junto con mis compañeros de clases:
<br>
<br>
{English}
<br>
This project was carried out in the semester 2021-2 of my university career. At that time, I collaborated significantly on the logic and the code of the program along with my classmates:
<br>
<br>
-Xavier Andrés De La Hoz Salas<br>
-Enzo Junior De Leon Pineda<br>
-Vanessa Paola Romero Domínguez<br>
-Me
